package collm.examplke.gm;

import androidx.annotation.DrawableRes;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{

    String TAG;
    private GoogleMap mMap;
    Marker test;
    Marker gaz;
    MainActivity m;
    Double value;
    Double value2;
    int type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        value = getIntent().getDoubleExtra("lx",4.0);
        value2 = getIntent().getDoubleExtra("ly",4.0);
        type=getIntent().getIntExtra("type",1);

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();

    }

    @Override
    protected void onPause() {
        super.onPause();
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onSaveInstanceState(Bundle outstate) {
        super.onSaveInstanceState(outstate);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    public Bitmap getMarkerBitmapFromView(@DrawableRes int resId,int i) {

        if (i == 1) {
            View customMarkerView = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.marker, null);
            ImageView markerImageView = (ImageView) customMarkerView.findViewById(R.id.rofile_image);
            markerImageView.setImageResource(resId);
            customMarkerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            customMarkerView.layout(0, 0, customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight());
            customMarkerView.buildDrawingCache();
            Bitmap returnedBitmap = Bitmap.createBitmap(customMarkerView.getMeasuredWidth(), customMarkerView.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(returnedBitmap);
            canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable drawable = customMarkerView.getBackground();
            if (drawable != null)
                drawable.draw(canvas);
                customMarkerView.draw(canvas);
                return returnedBitmap;

        } else if (i==2){

            View two = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markert, null);
            ImageView twoi = (ImageView) two.findViewById(R.id.file_image);
            twoi.setImageResource(resId);
            two.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            two.layout(0, 0, two.getMeasuredWidth(), two.getMeasuredHeight());
            two.buildDrawingCache();
            Bitmap returnedBitma = Bitmap.createBitmap(two.getMeasuredWidth(), two.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas canva = new Canvas(returnedBitma);
            canva.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable rawable = two.getBackground();
            if (rawable != null)
                rawable.draw(canva);
            two.draw(canva);
            return returnedBitma;
        }
        else if(i==3) {

            View tree = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markertr, null);
            ImageView treei = (ImageView) tree.findViewById(R.id.ile_image);
            treei.setImageResource(resId);
            tree.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            tree.layout(0, 0, tree.getMeasuredWidth(), tree.getMeasuredHeight());
            tree.buildDrawingCache();
            Bitmap returnedBit = Bitmap.createBitmap(tree.getMeasuredWidth(), tree.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas canv = new Canvas(returnedBit);
            canv.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable rawable = tree.getBackground();
            if (rawable != null)
                rawable.draw(canv);
            tree.draw(canv);
            return returnedBit;
        }
        else {
            View four = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.markerfo, null);
            ImageView fouri = (ImageView) four.findViewById(R.id.le_image);
            fouri.setImageResource(resId);
            four.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            four.layout(0, 0, four.getMeasuredWidth(), four.getMeasuredHeight());
            four.buildDrawingCache();
            Bitmap returnedBi = Bitmap.createBitmap(four.getMeasuredWidth(), four.getMeasuredHeight(),
                    Bitmap.Config.ARGB_8888);
            Canvas can = new Canvas(returnedBi);
            can.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
            Drawable rawable = four.getBackground();
            if (rawable != null)
                rawable.draw(can);
            four.draw(can);
            return returnedBi;
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        // Add a marker in Sydney and move the camera
        LatLng sba = new LatLng(37.421, -122.084);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(sba));
        mMap.setOnMarkerClickListener(this);

        mMap.animateCamera( CameraUpdateFactory.zoomTo( 13 ) );
        Log.d(TAG, "onMapReady() called with");

        MapsInitializer.initialize(this);
        addCustomMarker(value,value2,type);

    }


    @SuppressLint("ResourceType")
    public void addCustomMarker(double x,double y,int type) {

        // adding a marker on map with image from  drawable
     if(type==1){
      mMap.addMarker(new MarkerOptions()
              .position(new LatLng(x,y))
              .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.water,type)))).setTag(1);}
     else if (type==2){ mMap.addMarker(new MarkerOptions()
             .position(new LatLng(x,y))
             .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.route,type)))).setTag(2);}
     else if(type==3){mMap.addMarker(new MarkerOptions()
                 .position(new LatLng(x,y))
                 .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.electricite,type)))).setTag(3);}
     else if(type==4) {
         mMap.addMarker(new MarkerOptions()
                 .position(new LatLng(x, y))
                 .icon(BitmapDescriptorFactory.fromBitmap(getMarkerBitmapFromView(R.drawable.gas, type)))).setTag(4);
     }   }




    public boolean onMarkerClick(final Marker marker) {
 int a=(Integer)marker.getTag();
        if (a==1 || a==2)
        {

            mMap.setMapType(4);
            Intent myIntent = new Intent(MapsActivity.this, MainActivity.class);
            startActivity(myIntent);
        }

return false;
}
}

