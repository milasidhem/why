package collm.examplke.gm;


import android.widget.ImageView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Report {
    //proprietes
    private String title;
    private String description;
    private double locx;
    private double locy;
    private Integer type;
    private ImageView image;
    private Date date;

    public Report(String title, String description, double locx, double locy, Integer type, ImageView image, Date date) {
        this.title = title;
        this.description = description;
        this.locx = locx;
        this.locy = locy;
        this.type = type;
        this.image = image;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public double getLocx() {
        return locx;
    }

    public void setLocx(double locx) {
        this.locx = locx;
    }

    public void setLocy(double locy) {
        this.locy = locy;
    }

    public double getLocy() {
        return locy;
    }

    public Integer getType() {
        return type;
    }

    public ImageView getImage() {
        return image;
    }

    public Date getDate() {
        return date;
    }

    /**
     * convertion d'un report au format JSONArray
     * @return
     */
    public JSONArray convertToJSONArray(){
        List laList = new ArrayList();
        laList.add(title);
        laList.add(description);
        laList.add(locx);
        laList.add(locy);
        laList.add(type);
        laList.add(image);
        laList.add(date);
        return new JSONArray(laList);
    }
}

