package collm.examplke.gm;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    //proprietes
    int PERMISSION_ID = 44;
    FusedLocationProviderClient mFusedLocationClient;
    private EditText txttitle;
    private EditText txtdesc;
    private RadioButton type1;
    private RadioButton type2;
    private RadioButton type3;
    private RadioButton type4;
    private Button btnphoto;
    private Button btngps;
    private Button btnpost;
    private Controle controle;
    private TextView latTextView, lonTextView;



    /**
     * initialization des liens avec les objet
     */
    private void init(){
        txttitle = findViewById(R.id.txttitle);
        txtdesc = findViewById(R.id.txtdesc);
        type1 = findViewById(R.id.type1);
        type2 = findViewById(R.id.type2);
        type3 = findViewById(R.id.type3);
        type4 = findViewById(R.id.type4);
        latTextView = findViewById(R.id.latTextView);
        lonTextView = findViewById(R.id.lonTextView);
        this.controle = Controle.getInstance();
    }

    public void Local(View v){
        if(v==findViewById(R.id.btngps)){
            //Toast.makeText(MainActivity.this,"Localisation done",Toast.LENGTH_LONG).show();
            Log.d("message","********************* localisation");
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            getLastLocation();
        }
    }
    public void Photo(View v){
        if(v==findViewById(R.id.btnphoto))
            //Toast.makeText(MainActivity.this,"Photo done",Toast.LENGTH_LONG).show();
            Log.d("message","********************* photo");

    }
    public void Post(View v){
        if(v==findViewById(R.id.btnpost)){
            //Toast.makeText(MainActivity.this,"Report posted",Toast.LENGTH_LONG).show();
            Log.d("message","********************* post");
            String title = "";
            String description = "";
            double locx = 0;
            double locy = 0;
            Integer type = 1;
            ImageView image = null;
            // recuperation des donnees saisis
            title = txttitle.getText().toString();
            description = txtdesc.getText().toString();
            locx= Double.parseDouble(latTextView.getText().toString());
            locy= Double.parseDouble(lonTextView.getText().toString());
            if(type1.isChecked())
                type=1;
            else if(type2.isChecked())
                type=2;
            else if(type3.isChecked())
                type=3;
            else
                type=4;
            //controle des champs
            if(title.contentEquals("")||locx==0||locy==0){
                Toast.makeText(MainActivity.this,"Saisir incomplet",Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(MainActivity.this,"Report posted",Toast.LENGTH_LONG).show();
                this.controle.creeReport(title,description,locx,locy,type,image);


                Intent intent = new Intent(MainActivity.this, MapsActivity.class);


                intent.putExtra("lx",locx);
                intent.putExtra("ly",locy);
                intent.putExtra("type",type);
                startActivity(intent);




                           }

        }
    }

    @SuppressLint("MissingPermission")
    private void getLastLocation(){
        if (checkPermissions()) {
            if (isLocationEnabled()) {
                mFusedLocationClient.getLastLocation().addOnCompleteListener(
                        new OnCompleteListener<Location>() {
                            @Override
                            public void onComplete(@NonNull Task<Location> task) {
                                Location location = task.getResult();
                                if (location == null) {
                                    requestNewLocationData();
                                } else {
                                    latTextView.setText(location.getLatitude()+"");
                                    lonTextView.setText(location.getLongitude()+"");
                                }
                            }
                        }
                );
            } else {
                Toast.makeText(this, "Turn on location", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
        } else {
            requestPermissions();
        }
    }


    @SuppressLint("MissingPermission")
    private void requestNewLocationData(){

        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(0);
        mLocationRequest.setFastestInterval(0);
        mLocationRequest.setNumUpdates(1);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        mFusedLocationClient.requestLocationUpdates(
                mLocationRequest, mLocationCallback,
                Looper.myLooper()
        );

    }

    public LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            Location mLastLocation = locationResult.getLastLocation();
            latTextView.setText(mLastLocation.getLatitude()+"");
            lonTextView.setText(mLastLocation.getLongitude()+"");
            double a= mLastLocation.getLatitude();
        }
    };

    private boolean checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        return false;
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},
                PERMISSION_ID
        );
    }

    private boolean isLocationEnabled() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_ID) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLastLocation();
            }
        }
    }
    /*
    @Override
    public void onResume(){
        super.onResume();
        if (checkPermissions()) {
            getLastLocation();
        }

    }*/
}
