package collm.examplke.gm;

import android.util.Log;

import org.json.JSONArray;

public class AcceDistant implements AsyncResponse {

    // constants
    private static final String SERVERADDER = "http://192.168.1.37/serveurtest.php";
    private Controle controle;

    public AcceDistant(){
        controle = Controle.getInstance();
    }
    /**
     * retour de serveur distant
     * @param output
     */
    @Override
    public void processFinish(String output) {
        Log.d("SERVEUR", "***********************"+output);
        // decoupage du message recu avec %
        String[] message = output.split("%");
        // dans message[0] : "enreg"
        // dans message[1] : reste du message
    }
    public void envoi(String operation, JSONArray lesDonneesJSON){
        AcceHTTP acceDonnes = new AcceHTTP();

        // lien de délégation
        acceDonnes.delegate = this;

        // ajout parametres
        acceDonnes.addParam("operation",operation);
        acceDonnes.addParam("lesdonnees",lesDonneesJSON.toString());

        // appel au seurver
        acceDonnes.execute(SERVERADDER);
    }
}

