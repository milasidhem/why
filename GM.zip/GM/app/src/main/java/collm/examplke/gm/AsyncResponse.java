package collm.examplke.gm;


public interface AsyncResponse {
    void processFinish(String output);
}
