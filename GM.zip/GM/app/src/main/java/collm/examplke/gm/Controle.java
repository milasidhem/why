package collm.examplke.gm;
import android.content.Context;
import android.widget.ImageView;


import org.json.JSONArray;

import java.util.Date;

public final class Controle {

    private static Controle instance = null;
    private Report report;
    private static AcceDistant acceDistant;

    /**
     * constrecteur private
     */
    private Controle(){
        super();
    }

    /**pour qu'on avoir toujours une et une seule instance
     * creation de l'instance
     * @return instance
     */
    public static final Controle getInstance(){
        if(Controle.instance==null){
            Controle.instance = new Controle();
            acceDistant = new AcceDistant();
            //acceDistant.envoi("dernier",new JSONArray());
        }
        return Controle.instance;
    }

    /**
     * creation d'un report
     * @param title
     * @param description
     * @param locx
     * @param locy
     * @param type 1 pour problem d'eau et 2 pour voiri et 3 pour electricity et 4 pour gaz
     * @param image
     */
    public void creeReport(String title, String description, double locx, double locy, Integer type, ImageView image){
        Report unreport = new Report(title,description,locx,locy,type,image, new Date());
        acceDistant.envoi("enreg",unreport.convertToJSONArray());
    }

}

